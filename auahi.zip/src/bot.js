const discord = require('discord.js')
const fs = require('fs')

const bot = new discord.Client({
  intents: Object.values(discord.GatewayIntentBits)
})
bot.commands = new discord.Collection()

// Load commands
const app_commands = []
for (let category of fs.readdirSync('./src/commands')) {
  for (let command_file of fs.readdirSync(`./src/commands/${category}`)) {
    const command = require(`./commands/${category}/${command_file}`)
    bot.commands.set(command.info.name, command.execute)
    console.log(command_file)
    app_commands.push(command.info.toJSON())
  }
}
console.log(bot.commands)

bot.on('ready', () => {
  console.log('Bot online:', bot.generateInvite({
    scopes: ['bot', 'applications.commands'],
    permissions: ['ViewChannel', 'SendMessages', 'EmbedLinks', 'AttachFiles', 'AddReactions', 'UseExternalEmojis', 'UseExternalStickers', 'MentionEveryone', 'ReadMessageHistory', 'UseApplicationCommands', 'Connect', 'Speak', 'UseVAD']
  }))

  bot.application.commands.set(app_commands).then(() => console.log('Updated application commands'))
})

bot.on('interactionCreate', (interaction) => {
  if (!interaction.isCommand()) return
  if (!bot.commands.get(interaction.commandName)) return

  try {
    bot.commands.get(interaction.commandName)(interaction, bot)
  } catch (err) {
    console.warn(err)
    if (interaction.replied) interaction.editReply({ content: 'A fatal error occured while executing the command. Try again later.' })
    else interaction.reply({ content: 'A fatal error occured while executing the command. Try again later.' })
  }
})

module.exports = async function(token) {
  await bot.login(token)
  return bot
}