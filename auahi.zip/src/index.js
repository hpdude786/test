const noblox = require('noblox.js')
const setupBot = require('./bot')
const setupApi = require('./api')
const config = require('../config.json')

let bot;

async function init() {
  await noblox.setCookie(config.cookie)
  bot = await setupBot(config.token)
  setupApi()
}

init()
module.exports = bot