const express = require('express')
const fs = require('fs')

const app = express()

for (let file of fs.readdirSync('./src/endpoints')) {
  const endpoint = require(`./endpoints/${file}`)
  app[endpoint.method.toLowerCase()](endpoint.path, endpoint.execute)
}

module.exports = () => {
  app.listen(8071)
  return app
}