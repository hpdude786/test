const express = require('express')
const fs = require('fs')

module.exports = {
  path: '/activity',
  method: 'POST',

  /**
   * @param {express.Request} req 
   * @param {express.Response} res 
   */
  execute: async (req, res) => {
    if (!req?.headers?.authorization) return res.status(400).send('Unauthorized')
    if (req.headers.authorization != 'djfgadfklgjalkedfgjaeoirjgkjadflgkajerlkjgfadlfkgjalkrjklsdjafgarieogjafdlkgjarogjadfgakldrjgoiafdijgadfg') return res.status(400).send('Invalid authorization.')
    if (!req?.query?.player || !req?.query?.minutes || isNaN(Number(req.query.minutes))) return res.status(400).send('Invalid data.')

    if (!fs.existsSync('./src/activity.json')) fs.writeFileSync('./src/activity.json', '{}')
    delete require.cache[require.resolve('../activity.json')]

    const data = require('../activity.json')
    data[req.query.player] = Number(req.query.minutes) + (data[req.query.player] || 0)
    fs.writeFileSync('./src/activity.json', JSON.stringify(data, null, 2))
    res.status(200).send('Success')
  }
}