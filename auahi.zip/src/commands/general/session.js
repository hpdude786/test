const { SlashCommandBuilder, CommandInteraction, SlashCommandStringOption, Client } = require('discord.js')
const config = require('../../../config.json')

const TRAINING_MESSAGE = `**Training**

Greetings <@&${config.roles.pings.session}>
I am delighted to inform you that I am hosting a **Training Session** at the Training Center. Those ranked between **Trainee - Barista** can come down and train to perhaps gain a promotion if they pass. 

Link📎 | https://www.roblox.com/games/13207974523/Training-Center

I hope to see you there,
%USERNAME%
%ROLE%`
const SHIFT_MESSAGE = `**Shift**

Greetings <@&${config.roles.pings.session}>, 
I am delighted to inform you that I am hosting a **Shift** at the Cafe. Those ranked between **Trainee - Assistant Manager** can come down and attend to have a chance at a promotion and play some fun minigames with us. Everyone is welcome!
  
Link📎 | https://www.roblox.com/games/13196908460/FREE-UGC-Auahi-Cafe

I hope to see you there,
**%USERNAME%**
**%ROLE%**`

module.exports = {
  info: new SlashCommandBuilder()
    .setName('session')
    .setDescription('Announces a session in the session channel.')
    .setDMPermission(false)
    .addStringOption(option => 
      option.setName('type')
      .setDescription('The type of session to announce')
      .setRequired(true)
      .setChoices(
        { name: 'Shift', value: 'shift' },
        { name: 'Training', value: 'training' }
      )
    ),
  
  /**
   * @param {CommandInteraction} interaction 
   * @param {Client} bot
   */
  execute: async function (interaction, bot) {
    const type = interaction.options.get('type').value
    const channel = await bot.channels.fetch(config.channels.sessions)

    if (type == 'training') {
      if (!interaction.member.roles.cache.has(config.roles.sessions.training) && !interaction.member.permissions.has('Administrator')) return interaction.reply('no')
      await channel.send(TRAINING_MESSAGE.replace('%USERNAME%', interaction.user.username).replace('%ROLE%', interaction.member.roles.highest.name))
    } else if (type == 'shift') {
      if (!interaction.member.roles.cache.has(config.roles.sessions.shift) && !interaction.member.permissions.has('Administrator')) return interaction.reply('no')
      await channel.send(SHIFT_MESSAGE.replace('%USERNAME%', interaction.user.username).replace('%ROLE%', interaction.member.roles.highest.name))
    }                           

    interaction.reply('announced')
  }
}