const { SlashCommandBuilder, CommandInteraction } = require('discord.js')
const config = require('../../../config.json')

module.exports = {
  info: new SlashCommandBuilder()
    .setName('test')
    .setDescription('testtesttest')
    .setDMPermission(false),
  
  /**
   * @param {CommandInteraction} interaction 
   */
  execute: async function (interaction) {
    if (!interaction.member.roles.cache.has(config.roles.ranking) && !interaction.member.permissions.has('Administrator')) return interaction.reply('Permission denied')
    interaction.reply('Test')
  }
}