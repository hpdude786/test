const { SlashCommandBuilder, Client, CommandInteraction, SlashCommandStringOption, EmbedBuilder } = require('discord.js')
const { demote, getIdFromUsername, getPlayerThumbnail } = require('noblox.js')
const config = require('../../../config.json')

module.exports = {
  info: new SlashCommandBuilder()
    .setName('demote')
    .setDescription('Moves the specified user down one rank.')
    .setDMPermission(false)
    .addStringOption(
      new SlashCommandStringOption()
        .setName('username')
        .setDescription('The player\'s roblox username')
        .setRequired(true)
    ),

  /**
   * @param {CommandInteraction} interaction 
   * @param {Client} bot
   */
  execute: async function (interaction, bot) {
    if (!interaction.member.roles.cache.has(config.roles.ranking) && !interaction.member.permissions.has('Administrator')) return interaction.reply('Permission denied')

    const username = interaction.options.get('username').value
    const userid = await getIdFromUsername(username)
    const result = await demote(config.group, userid)
    await interaction.reply(`Successfully demoted @**${username}** from **${result.oldRole.name}** to **${result.newRole.name}**`)

    const logging = await bot.channels.fetch(config.channels.ranking_logs)
    await logging.send({
      embeds: [
        new EmbedBuilder()
          .setAuthor({ name: `@${username} Demoted` })
          .setColor('Red')
          .setTimestamp()
          .addFields([
            {
              name: 'Ranker',
              value: `@${interaction.user.username}`,
              inline: true
            },
            {
              name: 'Old Rank',
              value: result.oldRole.name,
              inline: true
            },
            {
              name: 'New Rank',
              value: result.newRole.name,
              inline: true
            }
          ]).toJSON()
      ]
    })
  }
}