const { SlashCommandBuilder, CommandInteraction, EmbedBuilder, Client, SlashCommandStringOption } = require('discord.js')
const { setRank, getIdFromUsername } = require('noblox.js')
const config = require('../../../config.json')

module.exports = {
  info: new SlashCommandBuilder()
    .setName('fire')
    .setDescription('Moves the specified user to the lowest rank.')
    .setDMPermission(false)
    .addStringOption(
      new SlashCommandStringOption()
        .setName('username')
        .setDescription('The player\'s roblox username')
        .setRequired(true)
    ),

  /**
   * @param {CommandInteraction} interaction 
   * @param {Client} bot
   */
  execute: async function (interaction, bot) {
    if (!interaction.member.roles.cache.has(config.roles.ranking) && !interaction.member.permissions.has('Administrator')) return interaction.reply('Permission denied')

    try {
      const username = interaction.options.get('username').value
      const userid = await getIdFromUsername(username)
      const result = await setRank(config.group, userid, 1)
      await interaction.reply(`Successfully ranked @**${username}** to **${result.name}**`)

      const logging = await bot.channels.fetch(config.channels.ranking_logs)
      await logging.send({
        embeds: [
          new EmbedBuilder()
            .setAuthor({ name: `@${username} Fired` })
            .setColor('Greyple')
            .setTimestamp()
            .addFields([
              {
                name: 'Ranker',
                value: `@${interaction.user.username}`,
                inline: true
              },
              {
                name: 'New Rank',
                value: result.name,
                inline: true
              }
            ]).toJSON()
        ]
      })
    } catch (err) {
      console.warn(err)
    }
  }
}