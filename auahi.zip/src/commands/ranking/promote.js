const { SlashCommandBuilder, CommandInteraction, EmbedBuilder, Client, SlashCommandStringOption } = require('discord.js')
const { promote, getIdFromUsername } = require('noblox.js')
const config = require('../../../config.json')

module.exports = {
  info: new SlashCommandBuilder()
    .setName('promote')
    .setDescription('Moves the specified user up one rank.')
    .setDMPermission(false)
    .addStringOption(
      new SlashCommandStringOption()
        .setName('username')
        .setDescription('The player\'s roblox username')
        .setRequired(true)
    ),

  /**
   * @param {CommandInteraction} interaction 
   * @param {Client} bot
   */
  execute: async function (interaction, bot) {
    if (!interaction.member.roles.cache.has(config.roles.ranking) && !interaction.member.permissions.has('Administrator')) return interaction.reply('Permission denied')

    try {
      const username = interaction.options.get('username').value
      const userid = await getIdFromUsername(username)
      const result = await promote(config.group, userid)
      await interaction.reply(`Successfully promoted @**${username}** from **${result.oldRole.name}** to **${result.newRole.name}**`)

      const logging = await bot.channels.fetch(config.channels.ranking_logs)
      await logging.send({
        embeds: [
          new EmbedBuilder()
            .setAuthor({ name: `@${username} Promoted` })
            .setColor('Green')
            .setTimestamp()
            .addFields([
              {
                name: 'Ranker',
                value: `@${interaction.user.username}`,
                inline: true
              },
              {
                name: 'Old Rank',
                value: result.oldRole.name,
                inline: true
              },
              {
                name: 'New Rank',
                value: result.newRole.name,
                inline: true
              }
            ]).toJSON()
        ]
      })
    } catch (err) {
      console.warn(err)
    }
  }
}