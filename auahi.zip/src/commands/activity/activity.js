const { SlashCommandBuilder, CommandInteraction } = require('discord.js')
const noblox = require('noblox.js')
const fs = require('fs')
const config = require('../../../config.json')

let confirmations = {}

module.exports = {
  info: new SlashCommandBuilder()
    .setName('activity')
    .setDescription('Handle all activity-related functions')
    .setDMPermission(false)
    .addSubcommand(command => 
      command.setName('reforms')
      .setDescription('Gets a list of all users who failed requirements.')
    )
    .addSubcommand(command => 
      command.setName('reset')
      .setDescription('Resets all activity tracking minutes.')
    )
    .addSubcommand(command => 
      command.setName('leaderboard')
      .setDescription('Gives you the leaderboard of the most active players.')
    )
    .addSubcommand(command =>
      command.setName('lookup')
      .setDescription('Looks up the minutes for a specific user.')
      .addStringOption(option =>
        option.setName('user')
        .setDescription('The username of the user to lookup.')
        .setRequired(true)
      )
    ),
  
  /**
   * @param {CommandInteraction} interaction 
   */
  execute: async function (interaction) {
    if (!interaction.member.permissions.has('Administrator')) return interaction.reply('Permission denied')
    const action = interaction.options.getSubcommand()

    if (action == 'reset') {
      if (!confirmations[interaction.user.id]) {
        confirmations[interaction.user.id] = true
        setTimeout(() => delete confirmations[interaction.user.id], 25000)
        return interaction.reply('Are you sure you want to reset ALL activity minutes? If so, run the command again.')
      }

      fs.writeFileSync('./src/activity.json', '{}')
      delete confirmations[interaction.user.id]
      interaction.reply('reset')
    } else if (action == 'reforms') {
      await interaction.deferReply()
      delete require.cache[require.resolve('../../activity.json')]
      const activity = require('../../activity.json')

      const roles = await noblox.getRoles(config.group)
      const failed = []

      for (const role of roles) {
        if (role.rank < 50 || role.rank >= 199) continue
        console.log(`Running on ${role.name}`)

        const users = await noblox.getPlayers(config.group, role.id)
        console.log(`Got ${users.length} users`)
        
        for (const { username, userId } of users) {
          const mins = activity[userId]
          if (!mins || mins < 120) failed.push(`**${username}** - **${mins || '0'}** minutes - ${role.name}`)
        }
      }

      await interaction.editReply(`Users who have failed requirements:\n\n${failed.length > 0 ? `${failed.map(x => `- ${x}`).join('\n')}` : '**nobody**'}`)
    } else if (action == 'lookup') {
      const user = interaction.options.get('user').value
      const userid = await noblox.getIdFromUsername(user)

      delete require.cache[require.resolve('../../activity.json')]
      const activity = require('../../activity.json')
      const minutes = activity[String(userid)] ?? 0

      interaction.reply(`**${minutes}** minutes`)
    } else if (action == 'leaderboard') {
      await interaction.deferReply()
      delete require.cache[require.resolve('../../activity.json')]
      let activity = Object.entries(require('../../activity.json')).sort((a,b) => b[1] - a[1]).slice(0, 20)
      let msg = ''

      for await (let [i, [user, minutes]] of Object.entries(activity)) {
        msg += `${Number(i) + 1}. **[@${await noblox.getUsernameFromId(Number(user))}](https://www.roblox.com/users/${user})** - ${minutes} minutes\n`
      }

      interaction.editReply(msg == '' ? 'No activity yet.' : msg)
    }
  }
}